<?php

namespace App\Http\Controllers;
use App\Models\TipoDeAnimal;

use Illuminate\Http\Request;

class TipoDeAnimalController extends Controller
{
    public function store(Request $request){
        $tipodeanimal = new TipoDeAnimal();
        $tipodeanimal ->descrição = $request->descrição;
        $tipodeanimal->save();
    }
    
    public function index(){
        $tipodeanimal = new TipoDeAnimal();
        return $tipodeanimal->all();
    }
    public function update(Request $request, $id){
        $tipodeanimal = TipoDeAnimal::find($id);
        $tipodeanimal ->descrição = $request->descrição;
        return $tipodeanimal->all();
    }
    public function destroy(){
        $tipodeanimal = new TipoDeAnimal();
        return $tipodeanimal->all();
    }
}
