<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Seeder;

class AnimalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('tipo_de_animal')->insert([
            'descrição' => 'Cachorro'
        ]);
        DB::table('tipo_de_animal')->insert([
            'descrição' => 'Gato'
        ]);
        DB::table('tipo_de_animal')->insert([
            'descrição' => 'Pássaro'
        ]);
        DB::table('tipo_de_animal')->insert([
            'descrição' => 'Coelho'
        ]);
    }
}
